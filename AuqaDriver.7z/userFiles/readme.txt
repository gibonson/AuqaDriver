file list:
- db.sqlite - bd file
- config_email.ini - email configuration
    [EMAIL]
    USER_NAME = 
    PASSWORD = 
    DEFAULT_RECIPIENT =  